# Weigence - Tareas UI (Frontend)

## ✅ Básico visual ()
- ✅ Colores y estilos ya aplicados
- [ ] Botones visuales para acciones futuras (ej. "Ver detalle", "Eliminar", "Descargar CSV", "Simular alerta")
- [ ] Mostrar íconos ✔️ ❌ junto a “Sí / No” en alertas
- [ ] Agregar un footer con autor, año o versión del sistema

---

