"""
Sockets package - WebSocket handlers para Weigence
"""
