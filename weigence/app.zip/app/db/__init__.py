"""
Database package - Consultas SQL optimizadas para Weigence
"""
