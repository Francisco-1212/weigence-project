// Iconos de severidad para recomendaciones IA
const AI_SEVERITY_ICONS = {
  info: 'info',
  warning: 'warning',
  critical: 'error',
  error: 'warning'
};