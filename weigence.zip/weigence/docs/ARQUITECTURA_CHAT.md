# 🏗️ Arquitectura del Sistema de Chat - Weigence

```
┌─────────────────────────────────────────────────────────────────┐
│                     FRONTEND (NO MODIFICADO)                     │
│                                                                  │
│  ┌────────────────────────────────────────────────────────┐    │
│  │  app/static/js/chat.js                                 │    │
│  │                                                          │    │
│  │  • UI completa del chat                                 │    │
│  │  • Gestión de conversaciones                            │    │
│  │  • Renderizado de mensajes                              │    │
│  │  • Polling cada 30s (opcional con WebSocket)           │    │
│  └────────────────────────────────────────────────────────┘    │
│                           │                                      │
│                           │ fetch()                              │
│                           ▼                                      │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                       BACKEND (NUEVO)                            │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  app/routes/chat.py (51 líneas)                          │  │
│  │                                                           │  │
│  │  @bp.route('/api/chat/usuarios')                         │  │
│  │  @bp.route('/api/chat/conversaciones')                   │  │
│  │  @bp.route('/api/chat/conversacion/crear')               │  │
│  │  @bp.route('/api/chat/mensajes/<id>')                    │  │
│  │  @bp.route('/api/chat/mensaje/enviar')                   │  │
│  │  @bp.route('/api/chat/mensaje/marcar-leido')             │  │
│  └───────────────────────┬──────────────────────────────────┘  │
│                          │                                      │
│                          │ llama a                               │
│                          ▼                                      │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  app/routes/chat_api.py (300+ líneas)                    │  │
│  │                                                           │  │
│  │  • Lógica de negocio                                     │  │
│  │  • Validación de sesión                                  │  │
│  │  • Manejo de errores                                     │  │
│  │  • Logging detallado                                     │  │
│  └───────────────────────┬──────────────────────────────────┘  │
│                          │                                      │
│                          │ usa                                   │
│                          ▼                                      │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  app/db/chat_queries.py (500+ líneas)                    │  │
│  │                                                           │  │
│  │  obtener_conversacion_entre_usuarios()                   │  │
│  │  crear_conversacion_1a1()                                │  │
│  │  obtener_conversaciones_usuario()                        │  │
│  │  obtener_mensajes_conversacion()                         │  │
│  │  crear_mensaje()                                         │  │
│  │  marcar_mensajes_leidos()                                │  │
│  │  obtener_usuarios_disponibles()                          │  │
│  │  validar_participante()                                  │  │
│  └───────────────────────┬──────────────────────────────────┘  │
│                          │                                      │
│                          │ SQL queries                           │
│                          ▼                                      │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                    BASE DE DATOS (Supabase)                      │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  usuarios                                                 │  │
│  │  • rut_usuario (PK)                                       │  │
│  │  • nombre, correo, rol                                    │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  conversaciones_chat                                      │  │
│  │  • id (PK)                                                │  │
│  │  • nombre, es_grupal, creado_por                          │  │
│  │  • ultima_actualizacion                                   │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  participantes_chat                                       │  │
│  │  • conversacion_id (FK)                                   │  │
│  │  • usuario_id (FK)                                        │  │
│  │  • ultimo_mensaje_leido                                   │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  mensajes_chat                                            │  │
│  │  • id (PK)                                                │  │
│  │  • conversacion_id (FK), usuario_id (FK)                  │  │
│  │  • contenido, fecha_envio                                 │  │
│  │  • editado, eliminado                                     │  │
│  └──────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                   WEBSOCKET (Tiempo Real)                        │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  app/sockets/chat_ws.py (350+ líneas)                    │  │
│  │                                                           │  │
│  │  Flask-SocketIO                                          │  │
│  │                                                           │  │
│  │  Eventos Cliente → Servidor:                             │  │
│  │  • connect / disconnect                                  │  │
│  │  • unirse_conversacion                                   │  │
│  │  • salir_conversacion                                    │  │
│  │  • mensaje_enviar                                        │  │
│  │  • escribiendo                                           │  │
│  │                                                           │  │
│  │  Eventos Servidor → Cliente:                             │  │
│  │  • mensaje_recibido                                      │  │
│  │  • usuario_escribiendo                                   │  │
│  │  • nueva_conversacion                                    │  │
│  └──────────────────────────────────────────────────────────┘  │
│                          ▲                                      │
│                          │                                      │
│                          │ emite eventos                         │
│                          │                                      │
│  ┌───────────────────────┴──────────────────────────────────┐  │
│  │  app/__init__.py                                          │  │
│  │                                                           │  │
│  │  • Inicializa SocketIO                                   │  │
│  │  • Registra eventos                                      │  │
│  │  • Integra con Flask                                     │  │
│  └──────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                         SERVIDOR                                 │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  app.py                                                   │  │
│  │                                                           │  │
│  │  if socketio_instance:                                   │  │
│  │      socketio.run(app, ...)  # Con WebSocket             │  │
│  │  else:                                                    │  │
│  │      app.run(...)            # Sin WebSocket             │  │
│  └──────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘


═══════════════════════════════════════════════════════════════════
                        FLUJO DE DATOS
═══════════════════════════════════════════════════════════════════

1. Usuario envía mensaje desde chat.js
   │
   ├─→ POST /api/chat/mensaje/enviar
   │   │
   │   ├─→ chat.py → chat_api.api_chat_enviar_mensaje()
   │   │   │
   │   │   ├─→ chat_queries.crear_mensaje()
   │   │   │   │
   │   │   │   └─→ INSERT INTO mensajes_chat (Supabase)
   │   │   │
   │   │   └─→ chat_ws.emitir_mensaje_nuevo()
   │   │       │
   │   │       └─→ socket.emit('mensaje_recibido')
   │   │           │
   │   │           └─→ Todos los clientes en la sala reciben
   │   │
   │   └─→ Response JSON
   │
   └─→ Frontend actualiza UI


2. Usuario abre conversación
   │
   ├─→ GET /api/chat/mensajes/<id>
   │   │
   │   ├─→ chat.py → chat_api.api_chat_mensajes()
   │   │   │
   │   │   ├─→ chat_queries.obtener_mensajes_conversacion()
   │   │   │   │
   │   │   │   └─→ SELECT FROM mensajes_chat (Supabase)
   │   │   │
   │   │   └─→ Response JSON con historial
   │   │
   │   └─→ Frontend renderiza mensajes
   │
   └─→ socket.emit('unirse_conversacion')
       │
       └─→ join_room(conversacion_id)


═══════════════════════════════════════════════════════════════════
                    CARACTERÍSTICAS CLAVE
═══════════════════════════════════════════════════════════════════

✅ Separación de responsabilidades
   ├─ chat.py: Rutas Flask
   ├─ chat_api.py: Lógica de negocio
   ├─ chat_queries.py: Acceso a datos
   └─ chat_ws.py: Comunicación tiempo real

✅ Seguridad
   ├─ Validación de sesión en todas las rutas
   ├─ Verificación de participantes
   ├─ Sanitización de inputs
   └─ SQL injection protection (Supabase ORM)

✅ Performance
   ├─ Consultas optimizadas
   ├─ WebSocket rooms (broadcast selectivo)
   ├─ Paginación de mensajes
   └─ Caché de usuarios conectados

✅ Compatibilidad
   ├─ 100% compatible con chat.js existente
   ├─ API REST completa
   ├─ WebSocket opcional (fallback a polling)
   └─ Sin modificar frontend

✅ Mantenibilidad
   ├─ Código limpio y documentado
   ├─ Logging detallado
   ├─ Manejo de errores robusto
   └─ Tests fáciles de implementar
