"""
Rutas para gestión de usuarios (CRUD)
Accesible solo para administrador y supervisor
"""
from flask import render_template, request, redirect, url_for, flash, jsonify, session
from . import bp
from .decorators import requiere_rol
from api.conexion_supabase import supabase
from app.utils.security import hash_password, validar_fortaleza_password, validar_email, validar_rut_chileno, sanitizar_input
import re
import uuid
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


# Roles disponibles en el sistema
ROLES_DISPONIBLES = ['operador', 'supervisor', 'administrador']

# Permisos por rol (define qué secciones ve cada rol)
PERMISOS_POR_ROL = {
    'operador': ['dashboard', 'inventario', 'movimientos', 'ventas', 'alertas', 'perfil'],
    'supervisor': ['dashboard', 'inventario', 'movimientos', 'auditoria', 'ventas', 'alertas', 'usuarios', 'historial', 'recomendaciones', 'perfil'],
    'administrador': ['dashboard', 'inventario', 'movimientos', 'auditoria', 'ventas', 'alertas', 'usuarios', 'historial', 'recomendaciones', 'perfil']
}


@bp.route('/usuarios', methods=['GET'])
@requiere_rol('administrador', 'supervisor')
def usuarios():
    """Página principal de gestión de usuarios"""
    from app.utils.eventohumano import registrar_evento_humano
    from app.utils.sesiones_activas import registrar_usuario_activo
    
    # Registrar al usuario actual como activo al entrar a la página
    rut = session.get('usuario_id')
    nombre = session.get('usuario_nombre')
    rol = session.get('usuario_rol')
    if rut and nombre:
        registrar_usuario_activo(rut, nombre, rol)
        print(f"[USUARIOS-ROUTE] ✓ Usuario registrado al cargar página: {nombre} ({rut})")
    
    if session.get('last_page') != 'usuarios':
        usuario_nombre = session.get('usuario_nombre', 'Usuario')
        registrar_evento_humano("navegacion", f"{usuario_nombre} ingresó a Gestión de Usuarios")
        session['last_page'] = 'usuarios'
    try:
        # Obtener todos los usuarios
        response = supabase.table("usuarios").select("*").execute()
        usuarios_lista = response.data if response.data else []
        
        # Filtrar solo usuarios activos y campos sensibles en la vista
        usuarios_publicos = []
        for u in usuarios_lista:
            # Omitir usuarios desactivados
            if u.get('activo') == False:
                continue
                
            usuario_publico = {
                'rut_usuario': u.get('rut_usuario'),
                'nombre': u.get('nombre'),
                'correo': u.get('correo'),
                'rol': u.get('rol'),
                'fecha_registro': u.get('fecha_registro'),
                'numero celular': u.get('numero celular')
            }
            usuarios_publicos.append(usuario_publico)
        
        return render_template('pagina/usuarios.html', usuarios=usuarios_publicos, roles=ROLES_DISPONIBLES)
    
    except Exception as e:
        print(f"[USUARIOS] Error al cargar lista de usuarios: {e}")
        flash(f'Error al cargar usuarios: {str(e)}', 'danger')
        return redirect(url_for('main.dashboard'))


@bp.route('/api/usuarios', methods=['GET'])
@requiere_rol('administrador', 'supervisor')
def api_obtener_usuarios():
    """API para obtener lista de usuarios (formato JSON)"""
    try:
        response = supabase.table("usuarios").select("*").execute()
        usuarios_lista = response.data if response.data else []
        
        # Filtrar solo usuarios activos y campos sensibles
        usuarios_publicos = []
        for u in usuarios_lista:
            # Omitir usuarios desactivados
            if u.get('activo') == False:
                continue
                
            usuario_publico = {
                'rut_usuario': u.get('rut_usuario'),
                'nombre': u.get('nombre'),
                'correo': u.get('correo'),
                'rol': u.get('rol'),
                'fecha_registro': u.get('fecha_registro'),
                'numero celular': u.get('numero celular')
            }
            usuarios_publicos.append(usuario_publico)
        
        return jsonify({
            'success': True,
            'data': usuarios_publicos,
            'total': len(usuarios_publicos)
        }), 200
    
    except Exception as e:
        print(f"[API-USUARIOS] Error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@bp.route('/api/usuarios/<rut>', methods=['GET'])
@requiere_rol('administrador', 'supervisor')
def api_obtener_usuario(rut):
    """API para obtener un usuario específico"""
    try:
        response = supabase.table("usuarios").select("*").eq("rut_usuario", rut).execute()
        
        if not response.data or len(response.data) == 0:
            return jsonify({
                'success': False,
                'error': 'Usuario no encontrado'
            }), 404
        
        usuario = response.data[0]
        
        # Filtrar campos sensibles
        usuario_publico = {
            'rut_usuario': usuario.get('rut_usuario'),
            'nombre': usuario.get('nombre'),
            'correo': usuario.get('correo'),
            'rol': usuario.get('rol'),
            'fecha_registro': usuario.get('fecha_registro'),
            'numero celular': usuario.get('numero celular')
        }
        
        return jsonify({
            'success': True,
            'data': usuario_publico
        }), 200
    
    except Exception as e:
        print(f"[API-USUARIOS-GET] Error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


def validar_email(email):
    """Valida formato de email"""
    patron = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(patron, email) is not None


def validar_rut(rut):
    """Valida formato básico de RUT chileno"""
    # Formato esperado: XX.XXX.XXX-X o XXXXXXXX-X
    patron = r'^(\d{1,2}\.\d{3}\.\d{3}-\d|^\d{7,8}-\d)$'
    return re.match(patron, rut) is not None


@bp.route('/api/usuarios', methods=['POST'])
@requiere_rol('administrador', 'supervisor')
def api_crear_usuario():
    """API para crear nuevo usuario"""
    try:
        data = request.get_json(force=True, silent=True)
        
        if not data:
            return jsonify({'success': False, 'error': 'No se pudo procesar el JSON'}), 400
        
        print(f"[API-CREAR-USUARIO] Datos recibidos: {data.keys()}")
        
        # Obtener y validar datos (flexible con mayúsculas/minúsculas)
        rut = sanitizar_input(data.get('rut_usuario', '').strip())
        nombre = sanitizar_input(data.get('nombre', '').strip())
        correo = data.get('correo', '').strip().lower()
        rol = data.get('rol', '').strip().lower()
        numero_celular = sanitizar_input(data.get('numero_celular', data.get('numero celular', '')).strip())
        contraseña = data.get('contraseña', data.get('Contraseña', '')).strip()
        
        logger.info(f"[API-CREAR-USUARIO] Intento de crear usuario: {nombre} ({rut})")
        
        # Validaciones
        if not rut or not nombre or not correo or not rol or not contraseña:
            logger.warning(f"[API-CREAR-USUARIO] ✗ Campos faltantes")
            return jsonify({
                'success': False,
                'error': 'Todos los campos son requeridos'
            }), 400
        
        # Validar RUT chileno
        if not validar_rut_chileno(rut):
            return jsonify({
                'success': False,
                'error': 'RUT inválido'
            }), 400
        
        if not validar_email(correo):
            return jsonify({
                'success': False,
                'error': 'Email inválido'
            }), 400
        
        # Validar fortaleza de contraseña
        es_valida, mensaje_error = validar_fortaleza_password(contraseña)
        if not es_valida:
            return jsonify({
                'success': False,
                'error': mensaje_error
            }), 400
        
        if rol not in ROLES_DISPONIBLES:
            return jsonify({
                'success': False,
                'error': f'Rol inválido. Roles disponibles: {", ".join(ROLES_DISPONIBLES)}'
            }), 400
        
        # Verificar si el usuario ya existe
        existe = supabase.table("usuarios").select("*").eq("rut_usuario", rut).execute()
        if existe.data and len(existe.data) > 0:
            return jsonify({
                'success': False,
                'error': 'El usuario (RUT) ya existe'
            }), 409
        
        # Verificar si el email ya existe
        existe_email = supabase.table("usuarios").select("*").eq("correo", correo).execute()
        if existe_email.data and len(existe_email.data) > 0:
            return jsonify({
                'success': False,
                'error': 'El email ya está registrado'
            }), 409
        
        # Generar hash seguro de la contraseña
        try:
            password_hash = hash_password(contraseña)
        except ValueError as e:
            return jsonify({
                'success': False,
                'error': str(e)
            }), 400
        
        # Crear nuevo usuario
        nuevo_usuario = {
            'rut_usuario': rut,
            'nombre': nombre,
            'correo': correo,
            'rol': rol,
            'numero celular': numero_celular if numero_celular else None,
            'Contraseña': password_hash,
            'fecha_registro': datetime.now().isoformat(),
            'activo': True
        }
        
        logger.info(f"[API-CREAR-USUARIO] Creando usuario: {rut}")
        response = supabase.table("usuarios").insert(nuevo_usuario).execute()
        
        if hasattr(response, 'data') and response.data:
            logger.info(f"[API-CREAR-USUARIO] ✅ Usuario creado: {rut}")
            
            # Registrar evento de auditoría
            from app.utils.eventohumano import registrar_evento_humano
            admin_nombre = session.get('usuario_nombre', 'Administrador')
            registrar_evento_humano("crear_usuario", f"{admin_nombre} creó usuario: {nombre} ({rut}) con rol {rol}")
            
            return jsonify({
                'success': True,
                'message': 'Usuario creado correctamente',
                'usuario': nuevo_usuario
            }), 201
        else:
            print(f"[API-CREAR-USUARIO] ❌ Error al crear usuario")
            return jsonify({
                'success': False,
                'error': 'Error al crear el usuario'
            }), 500
    
    except Exception as e:
        print(f"[API-CREAR-USUARIO] Exception: {e}")
        import traceback
        print(traceback.format_exc())
        return jsonify({
            'success': False,
            'error': f'Error inesperado: {str(e)}'
        }), 500


@bp.route('/api/usuarios/<rut>', methods=['PUT'])
@requiere_rol('administrador', 'supervisor')
def api_editar_usuario(rut):
    """API para editar usuario existente"""
    try:
        data = request.get_json(force=True, silent=True)
        
        if not data:
            return jsonify({'success': False, 'error': 'No se pudo procesar el JSON'}), 400
        
        # Verificar que el usuario existe
        existe = supabase.table("usuarios").select("*").eq("rut_usuario", rut).execute()
        if not existe.data or len(existe.data) == 0:
            return jsonify({
                'success': False,
                'error': 'Usuario no encontrado'
            }), 404
        
        # Obtener datos a actualizar
        update_data = {}
        
        if 'nombre' in data and data['nombre']:
            update_data['nombre'] = data['nombre'].strip()
        
        if 'correo' in data and data['correo']:
            if not validar_email(data['correo']):
                return jsonify({'success': False, 'error': 'Email inválido'}), 400
            update_data['correo'] = data['correo'].strip()
        
        if 'rol' in data and data['rol']:
            if data['rol'] not in ROLES_DISPONIBLES:
                return jsonify({
                    'success': False,
                    'error': f'Rol inválido. Roles disponibles: {", ".join(ROLES_DISPONIBLES)}'
                }), 400
            update_data['rol'] = data['rol'].strip()
        
        # Flexible con nombre del campo de teléfono
        if 'numero_celular' in data:
            update_data['numero celular'] = data['numero_celular'].strip() if data['numero_celular'] else None
        elif 'numero celular' in data:
            update_data['numero celular'] = data['numero celular'].strip() if data['numero celular'] else None
        
        # Flexible con nombre del campo de contraseña
        if 'contraseña' in data and data['contraseña']:
            update_data['Contraseña'] = data['contraseña'].strip()
        elif 'Contraseña' in data and data['Contraseña']:
            update_data['Contraseña'] = data['Contraseña'].strip()
        
        if not update_data:
            return jsonify({
                'success': False,
                'error': 'No hay datos para actualizar'
            }), 400
        
        print(f"[API-EDITAR-USUARIO] Actualizando usuario: {rut} con datos: {update_data.keys()}")
        response = supabase.table("usuarios").update(update_data).eq("rut_usuario", rut).execute()
        
        if hasattr(response, 'data') and response.data:
            print(f"[API-EDITAR-USUARIO] ✅ Usuario actualizado: {rut}")
            
            # Registrar evento de auditoría
            from app.utils.eventohumano import registrar_evento_humano
            admin_nombre = session.get('usuario_nombre', 'Administrador')
            usuario_editado = existe.data[0].get('nombre', rut)
            campos = ', '.join(update_data.keys())
            registrar_evento_humano("editar_usuario", f"{admin_nombre} editó usuario {usuario_editado} ({rut}). Campos: {campos}")
            
            return jsonify({
                'success': True,
                'message': 'Usuario actualizado correctamente'
            }), 200
        else:
            print(f"[API-EDITAR-USUARIO] ❌ Error al actualizar usuario")
            return jsonify({
                'success': False,
                'error': 'Error al actualizar el usuario'
            }), 500
    
    except Exception as e:
        print(f"[API-EDITAR-USUARIO] Exception: {e}")
        import traceback
        print(traceback.format_exc())
        return jsonify({
            'success': False,
            'error': f'Error inesperado: {str(e)}'
        }), 500


@bp.route('/api/usuarios/<rut>', methods=['DELETE'])
@requiere_rol('administrador', 'supervisor')
def api_eliminar_usuario(rut):
    """API para eliminar usuario"""
    try:
        # Verificar que no es el mismo usuario logueado
        if session.get('usuario_id') == rut:
            return jsonify({
                'success': False,
                'error': 'No puedes eliminar tu propia cuenta'
            }), 400
        
        # Verificar que el usuario existe
        existe = supabase.table("usuarios").select("*").eq("rut_usuario", rut).execute()
        if not existe.data or len(existe.data) == 0:
            return jsonify({
                'success': False,
                'error': 'Usuario no encontrado'
            }), 404
        
        # Desactivar el usuario en lugar de eliminarlo (soft delete)
        print(f"[API-DESACTIVAR-USUARIO] Desactivando usuario: {rut}")
        response = supabase.table("usuarios").update({
            'activo': False,
            'fecha_desactivacion': datetime.now().isoformat()
        }).eq("rut_usuario", rut).execute()
        
        print(f"[API-DESACTIVAR-USUARIO] ✅ Usuario desactivado: {rut}")
        
        # Registrar evento de auditoría
        from app.utils.eventohumano import registrar_evento_humano
        admin_nombre = session.get('usuario_nombre', 'Administrador')
        usuario_desactivado = existe.data[0].get('nombre', rut)
        registrar_evento_humano("desactivar_usuario", f"{admin_nombre} desactivó usuario {usuario_desactivado} ({rut})")
        
        return jsonify({
            'success': True,
            'message': 'Usuario desactivado correctamente. Su historial se mantiene.'
        }), 200
    
    except Exception as e:
        print(f"[API-ELIMINAR-USUARIO] Exception: {e}")
        import traceback
        print(traceback.format_exc())
        return jsonify({
            'success': False,
            'error': f'Error inesperado: {str(e)}'
        }), 500


# ============================================================================
# RASTREO DE USUARIOS CONECTADOS
# ============================================================================

from app.utils.sesiones_activas import (
    registrar_usuario_activo,
    actualizar_heartbeat,
    eliminar_usuario,
    obtener_usuarios_conectados,
    obtener_total_conectados
)

@bp.route('/api/usuarios/conectados', methods=['GET'])
@requiere_rol('administrador', 'supervisor')
def api_usuarios_conectados():
    """API para obtener lista de usuarios actualmente conectados"""
    try:
        from datetime import datetime
        ahora = datetime.now().strftime('%H:%M:%S')
        
        # Obtener usuarios conectados con limpieza automática de inactivos
        usuarios_ruts, detalles = obtener_usuarios_conectados(timeout_minutos=2)
        
        logger.info(f"[API-CONECTADOS] 📊 [{ahora}] Consulta recibida")
        logger.info(f"[API-CONECTADOS] 👥 Total conectados: {len(usuarios_ruts)}")
        logger.info(f"[API-CONECTADOS] 📋 RUTs: {usuarios_ruts}")
        logger.info(f"[API-CONECTADOS] 📝 Detalles: {detalles}")
        
        response_data = {
            'success': True,
            'conectados': usuarios_ruts,
            'total': len(usuarios_ruts),
            'detalles': detalles
        }
        
        print(f"\n[API-CONECTADOS] 📤 Enviando respuesta: {response_data}\n")
        
        return jsonify(response_data), 200
    
    except Exception as e:
        logger.error(f"[API-CONECTADOS] ❌ Error: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return jsonify({
            'success': False,
            'error': str(e),
            'conectados': []
        }), 500


@bp.route('/api/usuarios/heartbeat', methods=['POST'])
def api_usuario_heartbeat():
    """Endpoint para que el frontend notifique que el usuario sigue conectado"""
    try:
        from datetime import datetime
        ahora = datetime.now().strftime('%H:%M:%S')
        
        if not session.get('usuario_logueado'):
            logger.debug(f"[HEARTBEAT] Intento sin autenticación")
            return jsonify({'success': False, 'error': 'No autenticado'}), 401
        
        rut = session.get('usuario_id')
        nombre = session.get('usuario_nombre')
        rol = session.get('usuario_rol')
        
        if rut:
            actualizar_heartbeat(rut, nombre, rol)
            total = obtener_total_conectados()
            # Solo loguear cada 10 heartbeats para reducir ruido
            if not hasattr(actualizar_heartbeat, 'counter'):
                actualizar_heartbeat.counter = 0
            actualizar_heartbeat.counter += 1
            if actualizar_heartbeat.counter % 10 == 0:
                logger.debug(f"[HEARTBEAT] {nombre} ({rut}) - Total: {total}")
        else:
            logger.warning(f"[HEARTBEAT] No hay RUT en sesión")
        
        response_data = {
            'success': True,
            'usuario': nombre,
            'rut': rut,
            'total_conectados': obtener_total_conectados()
        }
        
        return jsonify(response_data), 200
    
    except Exception as e:
        logger.error(f"[HEARTBEAT] Error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

