// Placeholder para evitar 404/500 en cargas globales.
// El modal real no está definido en esta página; si se requiere funcionalidad,
// implementa aquí la lógica específica.
